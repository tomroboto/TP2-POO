package ar.com.centro8.java.curso.tests;

import java.text.DecimalFormat;

import ar.com.centro8.java.curso.ejercicios.encapsulamiento.figuras.entidades.Circulo;
import ar.com.centro8.java.curso.ejercicios.encapsulamiento.figuras.entidades.Rectangulo;
import ar.com.centro8.java.curso.ejercicios.encapsulamiento.figuras.entidades.TrianguloRectangulo;

public class TestFiguras {
    public static void main(String[] args) {
        //para redondear decimales podemos utilizar la clase DecimalFormat
        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("Clase Rectangulo");
        Rectangulo rectangulo1 = new Rectangulo(12, 25);
        System.out.println(rectangulo1);
        System.out.println("El perímetro del rectángulo1 es: " + df.format(rectangulo1.informarPerimetro()));
        System.out.println("La superficie del rectángulo1 es: " + df.format(rectangulo1.informarSuperficie()));

        System.out.println("\nClase Circulo");
        Circulo circulo1 = new Circulo(20);
        System.out.println(circulo1);
        System.out.println("El perímetro del círculo1 es: " + df.format(circulo1.informarPerimetro()));
        System.out.println("La superficie del círculo1 es: " + df.format(circulo1.informarSuperficie()));

        System.out.println("\nClase TrianguloRectangulo");
        TrianguloRectangulo trianguloRectangulo1 = new TrianguloRectangulo(12, 25);
        System.out.println(trianguloRectangulo1);
        System.out.println("El perímetro del triángulo_rectángulo1 es: " + df.format(trianguloRectangulo1.informarPerimetro()));
        System.out.println("La superficie del triángulo_rectángulo1 es: " + df.format(trianguloRectangulo1.informarSuperficie()));
    }
}
