package ar.com.centro8.java.curso.interfaces.implementaciones;

import ar.com.centro8.java.curso.interfaces.IArchivo;

public class ArchivoNube implements IArchivo {
    public String texto;

    @Override
    public void setText(String texto) {
        System.out.printf("Guardando <'%s'> en archivo de nube\n", texto);
        this.texto = texto;
    }

    @Override
    public String getText() {
        return this.texto;
    }

    @Override
    public String getTipo() {
        return "Archivo de nube";
    }
}
