package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.varargs.Cliente;
import ar.com.centro8.java.curso.entidades.varargs.Factura;

public class TestVarargs {
    public static void main(String[] args) {
        //Los varargs aparecen a partir del JDK 5
        //Son argumentos variables, sirven para crear métodos que permitan variar el número de parámetros que reciben.

        //creamos un cliente
        Cliente cliente1 = new Cliente("Kari");

        Factura factura1 = new Factura(1);
        Factura factura2 = new Factura(2);
        Factura factura3 = new Factura(3);
        Factura factura4 = new Factura(4);
        Factura factura5 = new Factura(5);
        Factura factura6 = new Factura(6);

        //agregamos una factura al cliente
        //cliente1.agregarFactura(factura1);
        cliente1.agregarFactura(factura1, factura2, factura3, factura4, factura5, factura6);
        System.out.println(cliente1);


    }
}
