package ar.com.centro8.java.curso.ejercicios.herencia.figuras.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class TrianguloRectangulo extends FiguraGeometrica{
    private double base;
    private double altura;

    @Override 
    public double informarPerimetro(){
        return base + altura + Math.hypot(base, altura);
    }

    @Override 
    public double informarSuperficie(){
        return base * altura / 2;
    }

}
