package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.ejercicios.herencia.figuras.entidades.Circulo;
import ar.com.centro8.java.curso.ejercicios.herencia.figuras.entidades.FiguraGeometrica;
import ar.com.centro8.java.curso.ejercicios.herencia.figuras.entidades.Rectangulo;
import ar.com.centro8.java.curso.ejercicios.herencia.figuras.entidades.TrianguloRectangulo;

public class TestEjercicioHerencia {
    public static void main(String[] args) {
        //creamos una referencia a la clase padre
        FiguraGeometrica figura;

        figura = new Circulo(25);
        System.out.println(figura.informarPerimetro());
        System.out.println(figura.informarSuperficie());

        figura = new Rectangulo(12, 35);
        System.out.println(figura.informarPerimetro());
        System.out.println(figura.informarSuperficie());

        figura = new TrianguloRectangulo(12, 88);
        System.out.println(figura.informarPerimetro());
        System.out.println(figura.informarSuperficie());
   
    }
}
