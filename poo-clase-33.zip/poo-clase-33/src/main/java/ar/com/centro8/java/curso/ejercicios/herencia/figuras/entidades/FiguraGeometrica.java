package ar.com.centro8.java.curso.ejercicios.herencia.figuras.entidades;

public abstract class FiguraGeometrica {

    public abstract double informarPerimetro();
    public abstract double informarSuperficie();
    
}
