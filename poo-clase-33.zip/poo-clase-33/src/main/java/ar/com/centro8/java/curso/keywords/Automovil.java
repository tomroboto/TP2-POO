package ar.com.centro8.java.curso.keywords;

import lombok.Getter;
import lombok.ToString;

@Getter 
@ToString 
public class Automovil {
    private final String marca;
    private final String modelo;
    private final String color;
    private static int velocidad;

    /*
     * final
     * cuando una variable o atributo es declarado final, queda constante. No se puede modificar su valor.
     * La keyword (palabra reservada) final a nivel atributo o variable determina que la misma
     * es una constante.
     * A nivel clase, la keyword final indica que esa clase no puede tener clases hijas o subclases
     */

    /*
     * static
     * Un atributo estático pertenece a la clase, no a los objetos.
     * Su estado es compartido por todas las instancias de la clase, ya que solo existe una copia.
     * Se accede a un atributo estático directamente a través del nombre de la clase.
     */

    public Automovil(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public static void frenar(int kilometros){
        if(kilometros > velocidad) velocidad=0;
        else velocidad -= kilometros;
    }
    //desde un método estático, solo puedo hacer referencia a atributos estáticos de la clase.
    //desde un método no estático, puedo llamar a miembros estáticos y no estáticos.

    //cuando un método es estático, significa que ese método pertenece a la clase
    //si el atributo que se modifica es estático, el método debe ser estático.
    //no podemos utilizar el .this porque hace referencia al objeto, y el atributo no pertenece al objeto en sí mismo,
    //pertenece a la clase.
    public static void acelerar(int kilometros){
        if(kilometros>0) velocidad+=kilometros;
        else System.out.println("Los kilómetros ingresados deben ser positivos.");
    }

    public static int getVelocidad(){
        return velocidad;
    }

}
