package ar.com.centro8.java.curso.tests;

import java.util.List;

import ar.com.centro8.java.curso.entidades.relaciones.Auto;
import ar.com.centro8.java.curso.entidades.relaciones.ClienteMayorista;
import ar.com.centro8.java.curso.entidades.relaciones.ClienteMinorista;
import ar.com.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.com.centro8.java.curso.entidades.relaciones.EmpleadoAgregaciones;
import ar.com.centro8.java.curso.entidades.relaciones.EmpleadoAsociacionSimple;
import ar.com.centro8.java.curso.entidades.relaciones.EmpleadoComposicion;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("Testeo de la clase Cuenta:");
        //creamos un objeto de la clase Cuenta:
        Cuenta cuenta1 = new Cuenta(1, "Pesos argentinos");
        System.out.println(cuenta1);
        cuenta1.depositar(10000);
        cuenta1.depositar(-10000);
        cuenta1.debitar(-10000);
        cuenta1.debitar(5000);
        System.out.println("El saldo de la cuenta1 es de " + cuenta1.getSaldo());
        // cuenta1.saldo = 0; error, porque el atributo es privado
        // cuenta1.setSaldo(0);  error, no existe el setter para el saldo.
        cuenta1.debitar(5000);
        System.out.println(cuenta1);

        System.out.println("\nTesto de la clase ClienteMinorista:");
        //creamos un objeto de la clase ClienteMinorista
        ClienteMinorista cliente1 = new ClienteMinorista(1, "Mario", "Baracus");
        System.out.println(cliente1);
        cliente1.setCuenta(cuenta1);
        System.out.println(cliente1);

        ClienteMinorista cliente2 = new ClienteMinorista(2, "James", "Hetfield", new Cuenta(2, "Dólares"));
        System.out.println(cliente2);

        //depositar 10.000 al cliente1
        // cliente1.depositar(10000); error, el método depositar no pertenece a la clase ClienteMinorista
        cliente1.getCuenta().depositar(10000);
        System.out.println(cliente1);

        //crear un apuntador o referencia
        Cuenta cta2 = cliente2.getCuenta();
        cta2.depositar(15000);
        System.out.println(cta2.getSaldo());
        System.out.println(cliente2); 

        System.out.println("\nTest de la clase ClienteMayorista");
        ClienteMayorista cliente3 = new ClienteMayorista(3, "El gallo loco", "Independencia 3");
        System.out.println(cliente3);

        //creamos un apuntador para acceder a las cuentas del cliente3
        List<Cuenta> mCuentas3 = cliente3.getCuentas();

        //con el método add() agrego cuentas a la lista
        Cuenta cuenta2 = new Cuenta(2, "reales");
        Cuenta cuenta3 = new Cuenta(3, "yuanes");
        Cuenta cuenta4 = new Cuenta(4, "yuanes");

        mCuentas3.add(cuenta2); //agregamos la cuenta2 a la lista de cuentas del cliente3
        mCuentas3.add(cuenta3);
        mCuentas3.add(cuenta4);
        mCuentas3.add(new Cuenta(5, "Libras esterlinas"));

        System.out.println(cliente3.getCuentas());

        //con el método get() obtengo las cuentas de la lista, pasando como parámetro un número entero 
        //que representa al índice del elemento.
        mCuentas3.get(0).depositar(10000); //depositamos 10.000 en la cuenta 2 de reales del cliente3.
        
        System.out.println("\n==================================================================\n");

        //creamos objetos de Auto
        Auto auto1 = new Auto("Peugeot", "209", "Gris");
        Auto auto2 = new Auto("Renault", "Clío", "Blanco");
        //Auto auto3 = new Auto("Citroën", "Picasso", "Violeta");
        
        //creamos un objeto de la clase EmpleadoAsociacionSimple
        System.out.println("\nEmpleadoAdociacionSimple");
        EmpleadoAsociacionSimple empleado1 = new EmpleadoAsociacionSimple(1, "Silvester", "Stallone");
        System.out.println(empleado1);
        empleado1.usarAuto(auto1);

        //creamos un objeto de la clase EmpleadoAgregaciones
        System.out.println("\nEmpleadoAgregaciones");
        EmpleadoAgregaciones empleado2 = new EmpleadoAgregaciones(2, "Charles", "Chaplin");
        System.out.println(empleado2);
        empleado2.setAuto(auto2);

        //creamos un objeto de la clase EmpleadoComposicion
        EmpleadoComposicion empleado3 = new EmpleadoComposicion(3, "Homero", "Thompson", "Ford", "Taunus", "Rojo fuego");
        System.out.println(empleado3);
        System.out.println(empleado3.getAuto());

    }
}
