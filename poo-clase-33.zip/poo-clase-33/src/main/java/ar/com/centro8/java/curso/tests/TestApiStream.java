package ar.com.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.com.centro8.java.curso.entidades.colecciones.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        /*
        API STREAM (incorporada en Java 8)
        
        La API Stream permite procesar secuencias de elementos provenientes de distintas fuentes, como colecciones, 
        arreglos o archivos.
        Proporciona una forma declarativa de trabajar con datos, permitiendo realizar operaciones como filtrar, 
        transformar, ordenar, recorrer y obtener resultados.
        Se utiliza frecuentemente junto con expresiones lambda e interfaces funcionales.
        
        ¿QUÉ ES UNA API? API (Application Programming Interface):
        Es un conjunto de reglas, métodos, clases e interfaces que permiten utilizar las funcionalidades de un software
        sin necesidad de conocer su implementación interna.
        Algunas API también permiten la comunicación entre diferentes aplicaciones o sistemas, como las API web.
        
        ANALOGÍA DE UNA API: 
        Imaginemos que estamos en un restaurante.
        - La carta representa la API: nos indica qué podemos pedir.
        - El mozo recibe nuestro pedido y lo comunica a la cocina.
        - La cocina realiza el trabajo necesario.
        Nosotros no necesitamos conocer cómo se prepara el plato, solamente debemos saber cómo solicitarlo.
        
        ¿QUÉ ES UN STREAM? 
        Es una secuencia de elementos sobre la que podemos realizar operaciones de procesamiento.
        Un Stream no es una colección y no almacena directamente los elementos. Permite procesar datos obtenidos de una 
        fuente.
        Las operaciones de un Stream se organizan generalmente en:
        - Fuente: de dónde provienen los elementos.
        - Operaciones intermedias: permiten filtrar o transformar los elementos, por ejemplo filter() y map().
        - Operación terminal: inicia el procesamiento y produce un resultado o efecto, por ejemplo forEach() o count().
        Las operaciones intermedias son perezosas (lazy): no procesan los elementos hasta que se ejecuta una operación 
        terminal.
        
        ¿QUÉ ES UN PREDICADO? 
        Es una función o expresión que recibe un valor y devuelve un resultado booleano (true o false).
        
        En Java existe la interfaz funcional Predicate<T>, cuyo único método abstracto es: boolean test(T valor);
        Podemos implementar un Predicate mediante una lambda.
        Ejemplo: n -> n % 2 == 0
        Este predicado verifica si un número es par.
        
        Dentro de la API Stream, filter() recibe un Predicate para seleccionar los elementos que cumplen la condición.
        
        IMPORTANTE: 
        Los Streams permiten expresar qué procesamiento queremos realizar sin escribir manualmente toda la lógica
        de recorrido de los elementos.
        
        Un Stream normalmente se consume una sola vez.
        Para realizar otro procesamiento, debemos obtener un nuevo Stream desde la fuente.
        */

        //Creamos una lista de personas
        List<Persona> personas = new ArrayList<>();

        personas.add(new Persona(1, "Ana", 32));
        personas.add(new Persona(2, "Javier", 41));
        personas.add(new Persona(3, "Carlos", 22));
        personas.add(new Persona(4, "Romina", 55));
        personas.add(new Persona(5, "Raul", 27));
        personas.add(new Persona(6, "Miguel", 37));
        personas.add(new Persona(7, "Mónica", 47));
        personas.add(new Persona(8, "Marcela", 57));
        personas.add(new Persona(9, "Ricardo", 67));
        personas.add(new Persona(10, "Juan", 45));
        personas.add(new Persona(11, "Juan", 23));

        //haremos un paralelismo con consultas SQL haciendo comparaciones sencillas con queries tradicionales.

        System.out.println("# select * from personas;");
        personas.forEach(System.out::println);

        //Stream provee métodos para filtrar.
        //El método stream() devuelve una implementación de la interfaz Stream.
        //El método filter() permite sobreescribir un predicado de expresión Lambda.
        //Un predicado es una interfaz funcional que define una condición que un objeto determinado debe cumplir.

        //buscamos personas con el nombre Ana
        System.out.println("\nselect * from personas where nombre='Ana';");
        personas
                .stream() //devuelve una secuencia de elementos para procesarlos (no guarda los elementos)
                .filter(p -> p.getNombre().equals("Ana")) //obtenemos un objeto del tipo Persona, luego va la expresión
                //booleana. Si devuelve true es parte de los resultados, si arroja false no forma parte de los resultados
                .forEach(System.out::println); //filter devuelve un stream con todos los registros, lo recorremos. 

        System.out.println("\nselect * from personas where nombre='Ana' or nombre='Juan';");
        personas
                .stream()
                .filter(p->p.getNombre().equals("Ana") || p.getNombre().equals("Juan"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like 'ja%';");
        personas
                .stream()
                .filter(p -> p.getNombre().toLowerCase().startsWith("ja"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like '%a';");
        personas
                .stream()
                .filter(p -> p.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like '%ar%';");
        personas
                .stream()
                .filter(p -> p.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where edad >= 30;");
        personas
                .stream()
                .filter(p -> p.getEdad() >= 30)
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre='Juan' and edad >= 30;");
        personas
                .stream()
                .filter(p -> p.getNombre().equals("Juan") && p.getEdad() >= 30)
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like '%an%;");
        personas
                .stream()
                .filter(p -> p.getNombre().toLowerCase().contains("an"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas order by nombre;");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);
        //si solo llamo al método sorted(), la clase Persona tiene que implementar la interfaz Comparable sobreescribiendo
        //el método compareTo().
        //El método compareTo() es parte de la interfaz Comparable y se utiliza para definir el orden natural de los objetos
        //Pero no termina siendo una solución flexible, ya que si tuviésemos que cambiar el ordenamiento, deberíamos cambiar
        //la implementación de compareTo, y eso sería muy costoso.

        System.out.println("\nselect * from personas order by edad;");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getEdad))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas order by nombre, edad;");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre)
                .thenComparing(Persona::getEdad)) //thenComparing se usa para definir criterios de ordenación adicionales
                .forEach(System.out::println);

        System.out.println("\nselect * from personas order by nombre desc, edad;");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre)
                .reversed() //invierte el criterio de ordenamiento
                .thenComparing(Persona::getEdad))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas order by id;");
        personas    
                .stream()
                .sorted(Comparator.comparingInt(Persona::getId)) //comparingInt() trabaja la comparación sobre números enteros
                //mejora la performance
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where edad between 30 and 40 order by nombre;");
        personas
                .stream()
                .filter(p -> p.getEdad() >= 30 && p.getEdad() <= 40)
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);

        System.out.println("\nselect max(edad) from personas;");
        personas
                .stream()
                .max(Comparator.comparing(Persona::getEdad)) //max devuelve un objeto de Optional, no una lista
                .get() //obtenemos el valor del objeto Optional, es decir, un objeto de la clase Persona
                .getEdad(); //obtenemos la edad del objeto Persona que viene del Optional.

        System.out.println(
                personas
                        .stream()
                        .max(Comparator.comparing(Persona::getEdad)) //max devuelve un objeto de Optional, no una lista
                        .get() //obtenemos el valor del objeto Optional, es decir, un objeto de la clase Persona
                        .getEdad() //obtenemos la edad del objeto Persona que viene del Optional.
        );
        
        int edadMaxima=
                personas
                .stream()
                .max(Comparator.comparing(Persona::getEdad))
                .get()
                .getEdad();

        System.out.println("\nselect * from personas where edad=(select max(edad) from personas);");
        personas
                .stream()
                .filter(p->p.getEdad()==edadMaxima)
                .forEach(System.out::println);

        /*personas
                .stream()
                .filter(p-> p.getEdad()==(
                        personas
                                .stream()
                                .max(Comparator.comparingInt(Persona::getEdad))
                                .get()
                                .getEdad()
                ))
                .forEach(System.out::println);*/

        /*
        * Método toList() - API Stream (incorporado en Java 16)
        *
        * El método toList() es una operación terminal de Stream que
        * permite obtener una lista con los elementos resultantes
        * del procesamiento realizado.
        *
        * A diferencia de forEach(), que ejecuta una acción sobre
        * cada elemento, toList() devuelve una List que podemos
        * almacenar en una variable para utilizarla posteriormente.
        *
        * - Es una operación terminal: finaliza el procesamiento del Stream.
        * - Devuelve un objeto que implementa la interfaz List.
        * - No modifica la colección original.
        * - Conserva el orden de los elementos, si el Stream tiene
        *   un orden definido.
        * - La lista resultante no permite agregar, eliminar ni
        *   reemplazar elementos (es una lista no modificable).
        *
        * IMPORTANTE:
        * El método Stream.toList() está disponible desde Java 16.
        * En Java 8 se utilizaba collect(Collectors.toList()).
        */


        //select * from personas where edad >= 40;
        System.out.println("\nselect * from personas where edad >= 40;");

        //Obtenemos una nueva lista con las personas de 40 años o más
        List<Persona> personasMayores = personas
                        .stream()
                        .filter(p->p.getEdad()>=40)
                        .toList(); //convierte el resultado del Stream en una List

        //Recorremos la lista obtenida
        personasMayores.forEach(System.out::println);


        //select * from personas where edad >= 40 order by nombre;
        System.out.println("\nselect * from personas where edad >= 40 order by nombre;");

        //Filtramos, ordenamos y almacenamos el resultado en una nueva lista
        List<Persona> personasOrdenadas = personas
                        .stream()
                        .filter(p->p.getEdad()>=40)
                        .sorted(Comparator.comparing(Persona::getNombre))
                        .toList();

        //Podemos utilizar esta lista en cualquier otra parte del programa
        System.out.println("Cantidad de personas: " + personasOrdenadas.size());
        personasOrdenadas.forEach(System.out::println);

        /*
        MÉTODO reduce() - API Stream
        
        Es una operación terminal que combina los elementos de un Stream hasta obtener un único resultado (por ejemplo, una suma o un máximo).
        
        La operación que combina dos valores se llama acumulador.
        Se puede definir con una expresión lambda o una referencia a método.
        
        reduce(valorInicial, acumulador):
        - valorInicial o identidad: valor desde el que comenzamos a acumular.
        - acumulador: recibe el resultado parcial y el siguiente elemento, devuelve el nuevo resultado acumulado.
        - En esta versión, reduce() devuelve directamente un resultado.
        
        reduce(acumulador):
        - No recibe un valor inicial.
        - Devuelve un Optional porque el Stream podría estar vacío.
        
        El acumulador es un BinaryOperator<T>, una interfaz funcional que recibe dos valores del mismo tipo y devuelve otro del mismo tipo.
        Para que funcione correctamente, la operación debe ser asociativa.
        */

        //Ejemplo
        //Sumar las edades de todas las personas
        System.out.println("\nselect sum(edad) from personas;");
        int sumaEdad= personas
                                .stream()
                                .map(p->p.getEdad()) //Transforma cada Persona en su edad Stream<Integer>
                                .reduce(0, (acumulador, edad)-> acumulador+edad);
                                //En este caso 0 es el valor inicial y el acumulador va sumando cada edad
        System.out.println("La suma de todas las edades es: "+sumaEdad);

        //Ejemplo:
        //Obtener la edad máxima con reduce()
        System.out.println("\nselect max(edad) from personas;");
        personas
                .stream()
                .map(Persona::getEdad)
                .reduce(Integer::max)
                .ifPresent(edad->System.out.println("Edad máxima: "+ edad));
                //ifPresent() solo imprime si existe un resultado
                //para obtener un máximo, normalmente es más claro utilizar max().

    }
}
