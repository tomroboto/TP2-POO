package ar.com.centro8.java.curso.entidades.colecciones;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter 
@ToString 
@AllArgsConstructor 
@EqualsAndHashCode 
public class Auto implements Comparable<Auto> {
    private String marca;
    private String modelo;
    private String color;

    @Override
    public int compareTo(Auto auto) {
        String esteAuto = this.marca + "," + this.modelo + "," + this.color;
        String otroAuto = auto.marca + "," + auto.modelo + "," + auto.color;
        return esteAuto.compareTo(otroAuto);
        //utilizamos el método compareTo de la clase String para comparar ambas representaciones 
    }
    //este método no es muy performante, porque utiliza String, pero para esta instancia ahorra mucho código
    //y es de fácil mantenimiento.
    //Si al resultado lo multiplicamos por -1, obtenemos el orden inverso.

    /*
    El método compareTo se utiliza para realizar un ordenamiento natural.
    El ordenamiento natural significa el orden de clasificación que se aplica al objeto, por ejemplo el orden léxico
    para una cadena, orden numérico para ordenar enteros, etc.
    Este método compara al objeto de la clase con el objeto que ingresa como parámetro y devuelve:
    0 si son iguales
    -1 si el objeto de la clase es menor al que entró por parámetro
    1 si es mayor
    */

}
