package ar.com.centro8.java.curso.tests;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.Vector;

import ar.com.centro8.java.curso.entidades.colecciones.Auto;

public class TestColecciones {
    public static void main(String[] args) {
        /*
        La interfaz List representa una colección ordenada de elementos que permite acceder a ellos mediante índices.

        List agrega métodos basados en posición como:
        get(), set(), add(index, elemento) y remove(index).

        De esta interfaz derivan distintas implementaciones, cada una con diferentes características internas.

        ArrayList:
        - Usa internamente un arreglo dinámico.
        - Permite acceso rápido por índice.
        - Su tamaño puede crecer automáticamente.
        - Suele ser muy eficiente para recorrer elementos.

        LinkedList:
        - Usa internamente una lista enlazada.
        - Permite inserciones y eliminaciones más eficientes en ciertos escenarios.
        - El acceso por índice suele ser más lento.

        Vector:
        - También implementa List.
        - Es una clase antigua de Java.
        - Sus métodos están sincronizados automáticamente, lo que puede volverla más lenta.
        - Actualmente se prefiere usar ArrayList en la mayoría de los casos.

        En general:
        - ArrayList suele ser mejor para acceder y recorrer elementos.
        - LinkedList puede ser conveniente cuando hay muchas inserciones o eliminaciones frecuentes.
        */

        List lista;

        lista = new ArrayList<>();
        lista = new LinkedList<>();
        lista = new Vector<>();
        //hicimos polimorfismo

        //.add() es el método para agregar elementos a un list
        lista.add(new Auto("Peugeot", "308", "negro"));
        lista.add(new Auto("Chevrolet", "Corsa", "rojo"));
        lista.add("hola");
        //esta lista no tiene especificado un tipo de dato en particular, por lo tanto, será del tipo Object,
        //esto quiere decir que podrá guardar cualquier elemento de cualquier tipo de dato
        lista.add(80);
        lista.add(23.45);

        //recorrido de la lista con índices
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
        }
        //el método size devuelve la longitud de un List
        //el método get() devuelve el elemento del índice pasado como parámetro

        System.out.println();

        //recorrido con for-each
        for(Object coso:lista) System.out.println(coso);

        //.remove() método para eliminar un elemento
        lista.remove(3); //elimino el elemento de índice 3 (80)
        System.out.println();
        for(Object coso:lista) System.out.println(coso);

        /*
        * INTERFAZ Iterable<T>
        *
        * Iterable es una interfaz que permite recorrer los elementos de un objeto mediante un iterador.
        *
        * Es la interfaz de la que hereda Collection, y por lo tanto está presente en las colecciones como List, Set y Queue.
        *
        * Una excepción importante es Map, que no hereda de Iterable.
        *
        * Desde Java 5, Iterable permite utilizar el for mejorado (también conocido como for-each).
        *
        * A partir de Java 8 se incorporó a Iterable el método forEach(), que permite recorrer sus elementos y ejecutar 
        * una operación sobre cada uno de ellos.
        *
        * forEach() es un método DEFAULT: esto significa que tiene una implementación definida directamente dentro de 
        * la interfaz.
        *
        * La ventaja es que podemos delegar el recorrido al método forEach(), sin escribir explícitamente una estructura
        * de repetición como for o while.
        *
        * IMPORTANTE:
        * El recorrido sigue existiendo internamente.
        * Simplemente no necesitamos programarlo de manera explícita.
        */

        System.out.println("\n* Recorrido con método forEach() *");

        lista.forEach(item -> System.out.println(item));

        /*
        * ¿CÓMO FUNCIONA forEach()?
        *
        * El método forEach() recibe un argumento de tipo Consumer<T>.
        *
        * Consumer es una INTERFAZ FUNCIONAL de Java, incorporada en Java 8 y ubicada en el paquete java.util.function.
        *
        * Una interfaz funcional tiene un único método abstracto.
        * Puede tener también métodos default o static.
        *
        * En el caso de Consumer, ese método es:
        *
        *     void accept(T valor);
        *
        * Consumer representa una operación que:
        * - Recibe un argumento de tipo T.
        * - Ejecuta una acción sobre ese argumento.
        * - No devuelve ningún resultado (void).
        *
        * La letra T representa un TIPO GENÉRICO.
        * El tipo concreto dependerá de los elementos de la colección.
        *
        * Por ejemplo, si tenemos una LinkedList<String>, el Consumer recibirá elementos de tipo String.
        *
        *
        * EXPRESIONES LAMBDA
        *
        * Una expresión lambda permite proporcionar la implementación de una interfaz funcional mediante una sintaxis 
        * simplificada.
        *
        * Fueron incorporadas al lenguaje Java a partir de Java 8.
        *
        * Se las suele describir como funciones anónimas porque permiten definir un comportamiento sin declarar
        * explícitamente un método con nombre.
        *
        * Sin embargo, en Java una lambda se utiliza en el contexto de una interfaz funcional, como Consumer.
        *
        * SINTAXIS:
        *
        *     parámetros -> expresión o bloque de instrucciones
        *
        * El operador flecha (->) separa los parámetros del cuerpo de la expresión lambda. 
        *
        *ANÁLISIS DE NUESTRO EJEMPLO:
        *
        *     lista.forEach(item -> System.out.println(item));
        *
        * 1. lista:
        *    Es la colección que queremos recorrer.
        *
        * 2. forEach():
        *    Recorre los elementos y ejecuta la operación indicada.
        *
        * 3. item:
        *    Es el parámetro de la lambda.
        *    Representa el elemento que se está procesando.
        *    Su tipo se infiere automáticamente a partir del tipo de elementos de la colección.
        *
        * 4. ->:
        *    Es el operador de las expresiones lambda.
        *    Separa los parámetros de la operación a realizar.
        *
        * 5. System.out.println(item):
        *    Es la instrucción que se ejecutará por cada elemento.
        *
        * En definitiva, por cada elemento de la colección, se ejecutará una llamada a println().
        */

        System.out.println();

        //si quisiéramos definir más de una sentencia, tenemos que abrir un bloque de llaves.
        lista.forEach(item -> {
            System.out.println(item);
            System.out.println("-");
        }); //ejemplo ficticio de cómo ejecutar más de una línea de código en el cuerpo de la lambda.
        
        //Ventajas de utilizar foreach y lambdas
        //hay menos código ceremonioso, no necesitamos manejar índices ni declarar un bucle.
        //hay mayor claridad: se ve simplemente qué operación se aplica a cada elemento.
        //hay mayor flexibilidad: se puede pasar cualquier bloque de código, no solo imprimir por consola.

        //Referencia de métodos (Method Reference)
        System.out.println("\n* Recorrido con foreach simplificado *");
        //si solo vamos a escribir un única sentencia, podemos omitir el uso del iterador
        lista.forEach(System.out::println);
        //con el operador de 4 puntos :: le estamos indicando a Java que el ítem implícito, lo coloque como
        //argumento del método. 
        //Es una sintaxis moderna, prolija y abreviada. 

        System.out.println("\n** ListInterator *");
        /*
        ListIterator es una interfaz especializada para recorrer colecciones que implementan List.
        A diferencia del iterador simple (Iterator) o del método forEach() de Iterable, ListIterator ofrece funcionalidades
        adicionales:
        - recorrida bidireccional: permite avanzar y retroceder sobre las listas. 
        - tiene acceso a índices.
        - permite eliminar, reemplazar y agregar elementos durante la itereación.
        */

        List nombres = new ArrayList<>();
        nombres.add("Ricardo");
        nombres.add("Osvaldo");
        nombres.add("Alberto");
        nombres.add("Ana");
        nombres.add("Jenny");

        //Obtenemos el iterador de la lista
        ListIterator<String> li = nombres.listIterator();

        //recorrido hacia adelante
        System.out.println("\nRecorrido hacia adelante:");
        while (li.hasNext()) { //comprueba si queda al menos un elemento más por recorrer en adelante, devuelve un booleano
            int indice = li.nextIndex(); //índice del elemento que se devolverá
            String nombre = li.next(); //devuelve el siguiente elemento
            System.out.println("Índice " + indice + ": " + nombre);            
        }
        
        //recorrido hacia atrás
        System.out.println("\nRecorrido hacia atrás:");
        while (li.hasPrevious()) { //comprueba si queda algún elemento para recorrer hacia atrás
            int indice = li.previousIndex(); //devuelve el índice siguiente hacia atrás (el previo a la posición)
            String nombre = li.previous(); //devuelve el elemento que sigue (es el anterior al cursor)
            System.out.println("Índice " + indice + ": " + nombre);
        }

        //reemplazar elementos
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Alberto")){
                li.set("Claudio"); //reemplaza Alberto por Claudio
            }
        }

        System.out.println("\nLista después de modificar 'Alberto' por 'Claudio': " + nombres);

        //agregar elementos
        li = nombres.listIterator(); //reiniciamos el iterador para que vuelva a comenzar desde el principio
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Osvaldo")){
                li.add("Gustavo"); //agrega a Gustavo inmediatamente después de Osvaldo
            }
        }
        System.out.println("\nLista después de agregar a 'Gustavo' luego de 'Osvaldo': " + nombres);

        //eliminar elementos
        li = nombres.listIterator();
        while (li.hasNext()) {
            String nombre = li.next();
            if(nombre.equals("Jenny")){
                li.remove(); //elimina el elemento actual (Jenny)
            }
        }
        System.out.println("\nLista después de eliminar a 'Jenny': " + nombres);

        System.out.println("\n* Uso de Generics *");
        // Hasta ahora la lista que creamos es Object. Porque no especificamos el tipo de datos.
        // Para especificar el tipo de datos de una lista, lo hacemos a través de los Generics
        // Los Generics aparecieron a apartir del JDK5 y son una característica que permiten crear clases,
        // interfaces o métodos con tipos de datos parametrizados.
        // Esto significa que podemos definir estructuras de datos y métodos que funcionen con cualquier tipo de datos, 
        // pero manteniendo la seguridad de los tipos en tiempo de compilación.
        // Los Generics permiten que una clase o método trabaje con diferentes tipos de datos sin tener que escribir 
        // varias versiones del mismo código.
        List<Auto> lista2 = new ArrayList<>();
        //cabe aclarar también que no pueden crearse colecciones de tipos de datos primitivos,
        //en su lugar debemos utilizar los wrappers Integer -> int  Double -> double  Character -> char

        // al agregar un elemento a la lista, el IDE nos indica que el elemento debe ser del tipo Auto
        lista2.add(new Auto("Renault", "Clio", "Rojo"));
        // lista2.add("hola"); ERROR no puedo agregar cualquier elemento a la lista
        // si quiero asignar a una variable del tipo Auto un elemento de la lista de Object que es un auto
        // lo tengo que castear primero. Castear significa convertir el tipo de dato.
        // Esto funciona siempre y cuando la conversión tenga sentido y se pueda realizar.

        Auto auto1 = (Auto) lista.get(0);
        //si tomo un elemento de la lista2, no hace falta castearlo. Porque todos sus elementos son del tipo Auto
        Auto auto2 = lista2.get(0);

        //copiar los autos de lista a lista2
        //para copiar, tenemos que tener en cuenta que no todos los elementos de lista, son autos.
        lista.forEach(item -> {
            if(item instanceof Auto)
                lista2.add((Auto) item);
        });

        //vemos finalmente cómo quedó la lista2 con los agregados
        lista2.forEach(System.out::println);

        // ------------------------------------------------------------------------------------------------

        System.out.println("\n* Interface Set *");

        /*
        La interfaz Set implementa Collection y tiene 3 implementaciones.
        La interfaz Set provee una lista sin índices. 
        El mismo objeto contenido en la lista, es el índice.
        Por eso mismo, esta interfaz no admite valores duplicados.
        */

        Set<String> setSemana;

        //HashSet
        //La implementación de HashSet es la más veloz de todas la implementaciones de Set
        //Pero no garantiza un orden específico.
        //No admite valores duplicados.
        setSemana = new HashSet<>();

        //LinkedHashSet
        //Es otra implementación de Set.
        //No tiene duplicados ni índices.
        //Almacena los elementos en una lista enlazada, esto quiere decir que cuando recorramos la lista, vamos a ver
        //los elementos por orden de entrada
        setSemana = new LinkedHashSet<>();

        //TreeSet
        //La clase TreeSet implementa NavigableSet que a su vez, implementa SortedSet.
        //No tiene duplicados ni índices.
        //Al usar TreeSet, la clase del Generic debe implementar la interfaz Comparable.
        //Es una implementación que almacena los elementos por un orden natural.
        //Esto quiere decir que los elementos van a aparecer ordenados. En este caso, al ser del tipo String, van a
        //aparecer ordernados de forma alfabética.
        //No hace falta un código de ordenamiento específico. 
        setSemana = new TreeSet<>();

        //agregamos los días de la semana
        setSemana.add("lunes");
        setSemana.add("martes");
        setSemana.add("martes");
        setSemana.add("miércoles");
        setSemana.add("jueves");
        setSemana.add("viernes");
        setSemana.add("viernes");
        setSemana.add("sábado");
        setSemana.add("domingo");

        //No podemos hacer un recorrido por índices, porque no hay índices.
        //Podemos utilizar el método forEach() de la interfaz Iterable
        System.out.println("\nRecorrido del Set:");
        setSemana.forEach(System.out::println);

        //Creamos un Set del tipo Auto
        Set<Auto> setAutos;

        setAutos = new LinkedHashSet<>();
        //la lista se va mostrar en el mismo orden que fueron ingresados.

        setAutos = new HashSet<>();

        setAutos = new TreeSet<>();
        //La interfaz SortedSet requiere que la clase del Generic implemente Comparable.
        //Como la clase Auto no la implementa, vamos a tener una ClassCastException

        //agregamos los autos de la lista2 a setAutos
        //lista2.forEach(setAutos::add);
        //sería lo mismo que hacer
        //lista2.forEach(item -> setAutos.add(item));
        //O podríamos utilizar el método addAll() de la interfaz Collection
        setAutos.addAll(lista2);
        //este método permite ingresar una colección directamente.

        System.out.println("\nContenido de setAutos:");
        setAutos.forEach(System.out::println);

        //agregamos un auto al set 
        setAutos.add(new Auto("Chevrolet", "Corsa", "rojo"));
        setAutos.add(new Auto("Chevrolet", "Corsita", "rojo"));
        System.out.println();
        setAutos.forEach(System.out::println);
        //En principio, se muestran dos Chevrolet Corsa rojo, porque son dos objetos distintos, con el mismo estado.
        //Por eso, no se los considera iguales. 

        System.out.println("\nRecorrido con hashCode:");
        setAutos.forEach(item -> System.out.println(item +"\t" + item.hashCode()));

        //Recordemos que para que dos objetos con el mismo estado, sean considerados el mismo objeto
        //debemos sobreescribir en la clase, los métodos equals() y hashCode()

        //Luego de sobreescribir equals() y hashCode() en la clase Auto, ya no aparece repetido el auto.

        // -------------------------------------------------------------------------------------------------

        //Interface Queue
        /*
        Implementaciones Comunes:
        - **ArrayDeque:** Es una implementación eficiente para colas estándar donde se encolan elementos 
        en la parte de atrás y se desencolan desde la parte de adelante.
        - **PriorityQueue:** Organiza los elementos basándose en su orden natural o mediante un Comparator, 
        lo que permite manejar prioridades; en este caso, el orden de extracción puede no coincidir con el 
        orden de inserción.
        - **LinkedList:** También implementa Queue (a través de la interfaz Deque), y puede usarse para 
        representar una cola, aunque ArrayDeque suele ser preferida por su rendimiento.

        Las colas están diseñadas para procesar elementos en un cierto orden (usualmente FIFO: First In, First Out).
        Una vez que un elemento ha sido procesado o ya no es necesario en el contexto de la cola, se desencola 
        para que la cola pueda avanzar y atender el siguiente elemento.

        Conceptos Clave:
        - **Encolar:** Insertar un elemento en la parte trasera de la cola.
        - **Desencolar:** Eliminar el elemento que se encuentra en la parte delantera de la cola.
        - **FIFO:** El primer elemento en entrar es el primero en salir, lo que garantiza un procesamiento 
        en orden de llegada.
        */

        System.out.println("\n** Interface Queue **");
        Queue<Auto> colaAutos;

        colaAutos = new ArrayDeque<>();

        colaAutos = new PriorityQueue<>();

        /*
         PriorityQueue permite almacenar elementos de forma que el elemento con mayor prioridad 
         (según el orden natural o un Comparator definido) siempre se encuentre en la cabeza de la cola. 
         La prioridad se define ya sea mediante el orden natural de los elementos (por ejemplo, si implementan 
         Comparable) o mediante un objeto Comparator que se pase en el momento de la creación.
         En su implementación interna garantiza que el primer elemento sea siempre el de menor valor o 
         mayor prioridad, según el criterio definido. Pero el resto de la estructura no se encuentra 
         completamente ordenada. Solo se garantiza el orden relativo de la cabeza.
         Al encolar elementos reorganiza internamente su estructura para mantener la propiedad de que el menor 
         elemento (o de mayor prioridad) esté en la raíz.
         Al desencolar extraen el elemento en la cabeza. Cada extracción reordena su estructura para colocar el 
         siguiente elemento prioritario en la posición de cabeza.
         Al iterar sobre una PriorityQueue (por ejemplo, con un bucle for-each), el orden en el que se recorren 
         los elementos no es necesariamente el orden natural o el orden de prioridades. El iterador recorre el 
         arreglo que no está completamente ordenado.
        */

        //el método .offer() permite encolar un elemento
        colaAutos.offer(auto1);
        colaAutos.offer(auto2);
        colaAutos.offer(new Auto("Ford", "Ecosport", "blanca"));
        //existe también para la clase el método add() para agregar. La diferencia es cómo trabajan internamente.
        //con el método add() si la colección del tipo cola está completa, lanza una excepción.
        //offer() en cambio devuelve un valor booleano que dará false si no se pudo guardar el elemento, sin lanzar
        //una excepción.

        //Hay clases que implementan la interface Queue y representan estructuras de datos con una capacidad limitada.

        //para agregar más autos de una sola vez
        colaAutos.addAll(lista2);

        System.out.println("\nQueue colaAutos:");
        colaAutos.forEach(System.out::println);

        //el método size() permite obtener la longitud de la colección
        System.out.println("\nlongitud de colaAutos: " + colaAutos.size());

        //desencolar elementos. Lo hace del primero hacia el último
        //el método poll() desencola elementos, los recupera y los elimina.
        System.out.println("\nEliminando elementos...");
        while (!colaAutos.isEmpty()) { //isEmpty() indica si está vacía
            System.out.println(colaAutos.poll());
        }
        //el método remove() hace lo mismo, pero si la cola está vacía, lanza una excepción, en cambio poll()
        //devuelve un null.


        //Pilas
        /*
        Clase Stack        
        Representa una pila (stack) en Java.
        - Es una clase, no una interfaz, y pertenece al paquete java.util.
        - Hereda de Vector, una clase histórica de Java que implementa la interfaz List mediante un arreglo dinámico, 
        cuyo tamaño puede crecer cuando se agregan elementos.
        - Actualmente, para trabajar con listas generales, se suele preferir ArrayList en lugar de Vector cuando no se 
        requiere la sincronización que proporciona este último.
        - Como Stack hereda de Vector, también dispone de métodos para acceder y modificar elementos mediante índices.
          Sin embargo, esas operaciones no son propias del funcionamiento tradicional de una pila.
        - Stack implementa el comportamiento LIFO (Last In - First Out): el último elemento en ingresar es el primero 
        en salir.
        */

        Stack<Auto> pilaAutos = new Stack<>();

        //el método push() agrega un elemento al tope de la pila (apilar)
        pilaAutos.push(new Auto("Citroën", "C4", "gris"));

        //agregamos toda una colección
        pilaAutos.addAll(lista2);

        System.out.println("\n Stack pilaAutos:");
        pilaAutos.forEach(System.out::println);

        System.out.println("\nLongitud de la pila: " + pilaAutos.size());

        System.out.println("\nEliminar elementos de una pila:");
        //el método pop() elimina elementos de la pila (desapilar)
        while (!pilaAutos.isEmpty()) {
            System.out.println(pilaAutos.pop());
        }

        System.out.println("\nLongitud de la pila: " + pilaAutos.size());

    }
}
