package ar.com.centro8.java.curso.tests;

public class TestExceptions {
    public static void main(String[] args) {
        //System.out.println(10/0);

        //Manejo de excepciones
        //Estructura try - catch - finally (mecanismo para el manejo y control de excepciones)
        try { //Obligatorio (siempre)
                /*
                En este bloque se colocan todas las sentencias que puedan lanzar una Exception.
                Si no se produce ningún error, el bloque se ejecuta normalmente
                y salta al bloque finally, si es que existe, o continúa directamente
                con el resto del código si no existe ese bloque.
                Si se lanza una excepción, la ejecución del bloque try se detiene inmediatamente
                y se transfiere el control del código al bloque catch
                */
        } catch (Exception e) { //Obligatorio (la mayoría de las veces)
            /*
            En este bloque se definen las acciones para realizar cuando se produce una Exception.
            Se captura la excepción mediante un objeto del tipo Exception que contiene información sobre el error.
            El programa continúa su ejecución despues de este bloque, sin detenerse abruptamente.
            Luego salta al bloque finally si es que existe.
            */
        } finally { //opcional
            /*
            Este bloque se ejecuta siempre, independientemente de que se haya lanzado o no una Exception.
            Se utiliza para liberar recursos o realizar tareas de limpieza, como cerrar archivos, conexiones
            a bases de datos, etc.
            Las variables declaradas dentro de los bloques try o catch no son accesibles en este bloque,
            ya que el alcance (scope) es local a esos bloques.
            */
        }

        //Estas sentencias se ejecutan siempre
        //El programa termina normalmente

        //Ejemplo
        try {
            System.out.println(10/0);
            System.out.println("Sentencia que no se ejecuta");
        } catch (Exception e) {
            System.out.println("Mensaje del bloque catch");
            System.out.println(e); //Imprimimos el objeto de la excepción}
            System.out.println(e.getMessage()); //mensaje corto con la descripción del error
            System.out.println(e.getLocalizedMessage()); //Similar a getMessage pero devuelve un mensaje traducido
            //según la configuración regional si es que fue sobrescrita
            System.out.println(e.getCause()); //Retorna la causa que provocó la excepción actual, lo que permite
            //encadenar excepciones y entender la raíz del problema
            e.printStackTrace(); //Imprime la traza completa de la pila. Lo que facilita la depuración al mostrar
            //la secuencia de llamadas que condujeron la excepción.
        } finally {
            System.out.println("Bloque finally: este bloque se ejecutará siempre");
        }

        System.out.println("Mensaje fuera del bloque try-catch-finally: esta sentencia se ejecuta sin problemas haya o no una excepcion");
        System.out.println("El programa finaliza normalmente.");

        /*
        La gráfica muestra la jerarquía de clases que componen el manejo de excepciones en Java.

        - La clase raíz es Throwable, que hereda de Object. Esta clase representa todo aquello que puede "lanzarse" (throw)
         y que puede interrumpir el flujo normal del programa.

        - Throwable tiene dos subclases principales: Error y Exception.
        
        - Error:
            - Representa errores graves, generalmente relacionados con la JVM o fallos críticos de hardware 
            (por ejemplo, OutOfMemoryError, StackOverflowError, etc.).
            - Estos errores no están diseñados para ser capturados ni manejados, ya que indican condiciones de las que la
             aplicación, en la mayoría de los casos, no puede recuperarse.
            - Dentro de Error se encuentra AssertionError, que se lanza cuando falla una aserción (assert). Las aserciones se 
            utilizan principalmente para pruebas y diagnóstico, y se pueden habilitar o deshabilitar en tiempo de ejecución 
            mediante las opciones -ea (enable assertions) y -da (disable assertions).

        - Exception:
            - Representa condiciones anómalas que pueden ocurrir durante la ejecución del programa y que, en muchos casos, 
            pueden ser manejadas o recuperadas.
            - Dentro de Exception existen dos tipos:
                - **Checked exceptions**: Son aquellas que el compilador obliga a capturar o declarar en la firma de los métodos
                 (por ejemplo, IOException, SQLException, etc.). Estas excepciones heredan directamente de Exception.
                - **Unchecked exceptions** (o Runtime exceptions): Son aquellas que no es obligatorio capturar o declarar, ya que 
                generalmente indican errores de lógica o condiciones inesperadas (por ejemplo, NullPointerException, ArithmeticException, 
                ArrayIndexOutOfBoundsException, etc.). Estas excepciones heredan de RuntimeException.
            
        Resumen:
        - Throwable: Raíz de todos los objetos "lanzables" en Java.
        - Error: Errores graves que no deben (o no se pueden) manejar.
        - Exception: Condiciones de error que se pueden manejar, divididas en:
        - Checked exceptions: Obligatorias de capturar o declarar.
        - Unchecked exceptions: No obligatorias de capturar, usadas para errores de programación.
        */
    }
}
