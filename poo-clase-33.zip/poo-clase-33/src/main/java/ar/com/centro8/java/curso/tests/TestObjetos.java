package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.objetos.Dato;
import ar.com.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.com.centro8.java.curso.entidades.relaciones.herencia.Cliente;
import ar.com.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.com.centro8.java.curso.entidades.relaciones.herencia.Empleado;
import ar.com.centro8.java.curso.entidades.relaciones.herencia.Persona;

public class TestObjetos {

    public static void main(String[] args) {
        /*
        * En Java existe la clase Class, ubicada en el paquete java.lang.
        * En tiempo de ejecución, cada clase cargada por la JVM tiene una representación
        * mediante un objeto de tipo Class.
        *
        * Esto permite obtener información sobre una clase mientras el programa se está ejecutando.
        *
        * Lo que en POO solemos llamar atributos, en Java técnicamente se llaman campos
        * o fields. Mediante la API de reflexión, esos campos pueden representarse con
        * objetos de tipo Field, que pertenece al paquete java.lang.reflect.
        *
        * De la misma manera, los métodos de una clase pueden representarse mediante
        * objetos de tipo Method, también ubicado en java.lang.reflect.
        *
        * Esta es la base de la API de reflexión en Java, que permite inspeccionar
        * información de clases, campos, métodos y constructores en tiempo de ejecución.
        *
        * Normalmente nosotros no creamos objetos Field o Method directamente.
        * Los obtenemos a partir de un objeto Class usando métodos de reflexión.
        *
        * Las clases públicas de java.lang, como String, Object, System, Math y Class,
        * están disponibles automáticamente sin necesidad de importarlas.
        *
        * En cambio, los subpaquetes como java.lang.reflect no se importan automáticamente.
        * Por eso, para usar Field o Method, necesitamos importarlos explícitamente.
        */

        Direccion direccion1 = new Direccion("Medrano", 162, "2do", "8", "CABA");
        Cuenta cuenta1 = new Cuenta(1, "pesos argentinos");
        Persona persona1 = new Empleado("Serj", "Tankian", 60, direccion1, 1, 1000000);
        Persona persona2 = new Cliente("Ozzy", "Osbourne", 76, direccion1, 1, cuenta1);

        System.out.println(persona1);
        System.out.println(persona2);

        //creamos una variable del tipo Empleado y asignamos persona1
        // Empleado empleado1 = persona1;
        //Esto da error, porque si bien, apunta a un objeto de Empleado, está guardado en un contenedor mayor que es Persona

        //Para resolver esta situación tenemos que castear la asignación
        //Castear en Java significa covertir una variable de un tipo a otro.
        //Es una forma de indicarle al compilador que trate a un objeto o valor como si fuera de otro tipo de dato.
        // Empleado empleado1 = (Empleado) persona1;
        // System.out.println(empleado1);

        //En este caso, si lo que le pasamos al compilador no es un objeto de Empleado, va a arrojar una exception.
        //Para salvar esa situación, podríamos utilizar el operador instanceof con un operador ternario
        Empleado empleado1 = (persona1 instanceof Empleado) ? (Empleado) persona1 : null;
        System.out.println(empleado1);

        //Los objetos tienen acceso a los miembros de su clase más todo lo heredado de la clase padre y de la clase
        //Object (clase padre de todas las clases).
        //El objeto de una clase padre no puede tener acceso a miembros de las clases hijas. 

        System.out.println();

        Dato d1 = new Dato(2);
        Dato d2 = d1;
        Dato d3 = new Dato(d1.getDato());
        Dato d4 = new Dato(4);
        String st = "2";

        //El método hashCode() es un método heredado de la clase Object
        System.out.println("d1.hashCode():" + d1.hashCode()); //1721931908
        System.out.println("d2.hashCode():" + d2.hashCode()); //1721931908
        System.out.println("d3.hashCode():" + d3.hashCode()); //2046562095
        System.out.println("d4.hashCode():" + d4.hashCode()); //1342443276
        System.out.println("st.hashCode():" + st.hashCode()); //50
        //El código hash es un valor entero calculado por Java a partir del estado o identidad del objeto.
        //Este valor se utiliza principalmente en estructuras de datos hash para facilitar la búsqueda y el
        //almacenamiento eficiente de objetos.
        //No es la dirección de memoria del objeto. 

        //El método equals() también está definido en Object.
        //Compara a los objetos por medio de su código hash
        System.out.println("d1.equals(d1):" + d1.equals(d1)); //true
        System.out.println("d1.equals(d2):" + d1.equals(d2)); //true
        System.out.println("d1.equals(d3):" + d1.equals(d3)); //false
        System.out.println("d1.equals(d4):" + d1.equals(d4)); //false
        System.out.println("d1.equals(st):" + d1.equals(st)); //false

        //Puede darse la situación de que queramos contemplar que dos objetos con el mismo estado, sean considerados
        //el mismo objeto. Eso mismo pasa en la clase String. Si comparamos dos String con el método equals(), por más
        //que sean dos objetos en distinto lugar de memoria van a ser considerados el mismo objeto. Porque en la 
        // clase String, los métodos equals() y hashCode() fueron sobreescritos.  

        // /////////////////////////////////////////////////////////////////////////////////

        System.out.println("\n** Clase String**");

        //Podemos crear un objeto de la clase String de varias maneras.
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";

        //métodos para comparar
        //Al comparar con el operador == va a comparar que sean el mismo objeto en memoria}
        System.out.println(texto2 == "hola"); //false
        //Dio falso porque son distintos objetos en memoria, pero puede darse la posibilidad de que la comparación
        //diera verdadera.
        System.out.println(texto3 == "hola"); //true
        //Esto pasa porque se un comportamiento especial denominado "interning". Lo que sucede es que las cadenas
        //creadas con comillas dobles se almacenan en un pool de cadenas internas para ahorrar memoria, es decir, que
        //de manera interna ocuparían el mismo espacio en memoria. Por eso, se las considera iguales.
        //Comparar contenidos de cadenas con el == no brinda un comportamiento garantizado.

        //Para comparar cadenas de caracteres teniendo en cuenta su contenido, se utilizan los métodos
        //equals() o equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        //equals() compara literalmente las cadenas
        System.out.println(texto2.equals("HOLA")); //false
        //equalsIgnoreCase() ignora las minúsculas y mayúsculas
        System.out.println(texto2.equalsIgnoreCase("HOLA")); //true

        //mayúsculas y minúsculas
        //toLowerCase() para minúsculas y toUpperCase() para mayúsculas
        System.out.println(texto1.toLowerCase()); //cadena de texto!
        System.out.println(texto1.toUpperCase()); //CADENA DE TEXTO!

        //contains() 
        // devuelve un booleano si contiene la subcadena dada
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("hola")); //true
         
        //length()
        //devuelve la longitud del vector, es decir, cuántos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4

        //isEmpty()
        //indica si la cadena está vacía, es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false

        //isBlank() aparece a partir del JDK 11
        //indica si una cadena está en blanco o consiste únicamente en espacios en blanco
        //como por ejemplo si solo contiene espacios, tabulaciones y/o saltos en línea
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true

        //charAt()
        //devuelve el caracter del índice pasado como parámetro
        System.out.println(texto1.charAt(3)); //e
        System.out.println(texto2.charAt(3)); //a

        //indexOf()
        //devuelve el índice de la primera ocurrencia de la subcadena
        //si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto")); //devuelve -1, no la encuentra porque la T es mayúscula
        System.out.println(texto1.indexOf("Texto")); //devuelve 10, es el índice en donde comienza la subcadena

        //trim()
        //quita los espacios de adelante y de atrás
        System.out.println("   buenas noches   "); //   buenas noches   
        System.out.println("   buenas noches   ".trim());//buenas noches
        
        //startsWith() y endsWith()
        //devuelve un booleano si la cadena comienza o termina con una cadena determinada
        System.out.println(texto1.startsWith("hola")); //false
        System.out.println(texto2.startsWith("hola")); //true
        System.out.println(texto1.endsWith("exto")); //false
        System.out.println(texto1.endsWith("exto!")); //true

        //substring()
        // con un parámetro, devuelve la subcadena a partir del índice del parámetro hacia el final de la cadena
        System.out.println(texto1.substring(10)); //Texto!
        //con dos parámetros, devuelve la subcadena a partir del índice del primer parámetro y hasta uno antes del
        //índice del segundo parámetro
        System.out.println(texto1.substring(0, 6)); //Cadena
        
        //métodos replace

        //reemplazar un caracter por otro
        System.out.println(texto1.replace('e', 'i'));
        //reemplaza una cadena de caracteres por otra
        System.out.println(texto1.replace("Texto", "caracteres"));
        //reemplaza solo la primera vez que aparezca la cadena
        String texto5 = "manzana, manzana, naranja";
        System.out.println(texto5.replaceFirst("manzana", "banana"));
        //reemplaza todas las veces que aparezca la cadena
        System.out.println(texto5.replaceAll("manzana", "banana"));
        //Si bien replace() también reemplaza todas las veces que apareza la subcadena, el replaceAll() es más potente
        //nos permite buscar y reemplazar patrones de expresiones regulares.
        //Una expresión regular es una secuencia de caracteres que definen un patrón de búsqueda.
        //Las identificamos como regex o regexp
        String texto6 = "Mi número de teléfono personal es 011-8888-9999 y mi número de teléfono laboral es 356-1111-2222.";
        System.out.println(texto6.replaceAll("\\d{3}-\\d{4}-\\d{4}", "HIDDEN INFORMATION"));
        //En este caso, utilizamos un patrón de expresión regular que busca todas las ocurrencias de una cadena de
        //caracteres que coincida con el formato de ###-####-####

        //repeat() repite la cadena la cantidad de veces que se indique por parámetro
        System.out.println(texto2.repeat(3)); //holaholahola

        //Caracteres de escape
        //Son secuencias especiales de caracteres que se utilizan en cadenas de texto y literales de caracteres para
        //representar caracteres especiales o caracteres que no se pueden representar directamente.
        //Los caracteres de escape comienzan con una barra invertida (\) seguida de un caracter que indica qué tipo
        //de escape se está utilizando

        // \n salto de línea
        System.out.println("Hola\nMundo!");

        // \t tabulación
        System.out.println("Hola\tMundo!");

        // \" comillas dobles
        System.out.println("\"Hola Mundo!\"");

        // \\ barra invertida
        System.out.println("\\Hola Mundo!\\");

        // ====================================================================================================

        System.out.println();

        System.out.println("StringBuilder y StringBuffer");

        //iniciamos un String vacío
        String cadena = "";

        //hacemos un recorrido de 1 a 800.000
        //en cada vuelta vamos a concatenar una "x" a ese String
        //por lo tanto al final del recorrido, el String tendrá 800.000 caracteres
        /* for (int i = 0; i < 800000; i++) {
            cadena += "x";
        }
        System.out.println(cadena); */
        //El problema es que, dado que los Strings son inmutables, cada concatenación crea un nuevo arreglo de caracteres
        //copiando el contenido del String anterior y añadiendo una "x".
        //Esto genera muchas operaciones de copia y creación de objetos, afectando el rendimiento.

        //Si leemos un archivo y vamos concatenando cada caracter a un String, cada operación de concatenación crea un 
        //nuevo objeto String debido a la inmutabilidad de la clase String.
        //Eso significa que en un bucle, se generan muchos objetos intermedios, lo que relentiza la ejecución.

        //Para evitar ese problema, se recomienda utrilizar las clases StringBuilder o StringBuffer, que permiten construir
        //una secuencia de caracteres de forma mutable sin crear nuevos objetos en cada concatenación.
        //StringBuilder es más rápida, pero no es sincronizada, es ideal para entornos de un solo hilo.
        //StringBuffer es sincronizada, lo que la hace un poco más lenta, pero soporta un multiprocesamiento.

        StringBuilder sb = new StringBuilder();
        StringBuffer sf = new StringBuffer();

        //Tanto StringBuilder como StringBuffer mantienen internamente una secuencia de caracteres, gestionada en un array 
        //de caracteres que se redimensiona dinámicamente.
        for (int i = 0; i < 800000; i++) {
            sf.append("x");
        }
        System.out.println(sf);

    }

}
