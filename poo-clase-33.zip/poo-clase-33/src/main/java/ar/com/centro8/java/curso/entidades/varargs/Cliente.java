package ar.com.centro8.java.curso.entidades.varargs;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@ToString
public class Cliente {
    @Setter
    private String nombre;
    private List<Factura> facturas = new ArrayList<>();

    public Cliente(String nombre) {
        this.nombre = nombre;
    }
    
/*     public void agregarFactura(Factura f){
        facturas.add(f);
    } */

/*     public void agregarFactura(Factura f, Factura f2){
        facturas.add(f);
        facturas.add(f2);
    } */

    //Los métodos varargs se identifican por contener varios puntos, permitiendo pasar varios argumentos del 
    //mismo tipo.
    public void agregarFactura(Factura... facturasIngresadas){
        // for(Factura f:facturasIngresadas) facturas.add(f);
        for (int i = 0; i < facturasIngresadas.length; i++) {
            facturas.add(facturasIngresadas[i]);
        }
    }
    //Cuando hay varios parámetros en un método, el argumento variable debe ir a lo último
    //solo puede haber un único argumento variable como parámetro de un método.

}
