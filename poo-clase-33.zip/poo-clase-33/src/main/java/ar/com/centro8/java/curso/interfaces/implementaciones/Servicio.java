package ar.com.centro8.java.curso.interfaces.implementaciones;

import ar.com.centro8.java.curso.interfaces.IPagos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Servicio implements IPagos{
    //tanto producto como servicio son dos clases bien distintas que no tienen nada que ver una con otra 
    //y que sin embargo terminan utilizando la misma interface para gestionar los pagos
    private String descripción;
    private double tarifa;

    @Override
    public void pagarConTarjetaDeDebito(double monto) {
        // acá va toda la lógica de pago con tarjeta de débito
        System.out.println("Se realizó el cobro con tarjeta de débito");
    }

    @Override
    public void pagarConTarjetaDeCredito(double monto) {
        // acá va toda la lógica de pago con tarjeta de crédito
        System.out.println("Se aplicó un recargo del 10%");
        System.out.println("Total cobrado = " + redondearMonto(aplicarRecargo(monto, 10)));
    }

    @Override
    public void pagarConTransferencia(double monto) {
        // acá va toda la lógica de pago con transferencia
        System.out.println("Se realizó el cobro con transferencia");
    }

    @Override
    public void pagarConEfectivo(double monto) {
        // acá va toda la lógica de pago con efectivo
        System.out.println("Se aplicó un descuento del 10%");
        System.out.println("Total cobrado = " + redondearMonto(aplicarDescuento(monto, 10)));
    }

    @Override
    public void pagarConQR(double monto) {
        // acá va toda la lógica de pago con QR
        System.out.println("Se realizó el cobro con QR");
    }

    //de ambas clases, tanto Producto como Servicio de podría aplicar una herencia. 
    // Ambas clases podrían ser clases padres y luego las clases hijas definirían cada tipo de producto o servicio 
    // en particular.
    //Pero podría llegar a haber una nueva clase que no pertenezca a la herencia ni tenga nada que ver con estas dos 
    // clases en sí mismo pero que podría implementar la misma interface.
    
}

