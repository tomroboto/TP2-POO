package ar.com.centro8.java.curso.ejercicios.herencia.figuras.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Rectangulo extends FiguraGeometrica{
    private double base;
    private double altura;

    @Override 
    public double informarPerimetro(){
        return (base + altura) * 2;
    }

    @Override 
    public double informarSuperficie(){
        return base * altura;
    }
}
