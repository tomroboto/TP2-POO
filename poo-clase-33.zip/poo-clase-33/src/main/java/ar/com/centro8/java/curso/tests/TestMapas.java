package ar.com.centro8.java.curso.tests;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestMapas {
    public static void main(String[] args) {
        /*
        Interface Map
        
        La interfaz Map permite representar un diccionario o una estructura de datos de pares clave-valor.
        En un Map, cada clave (key) se asocia a un valor (value).
        Las claves no son índices numéricos ni posiciones como ocurre en las listas.
        Pueden ser objetos de diferentes tipos, como String, Integer, etc., según el tipo definido al declarar el Map.
        Esto permite representar relaciones o asociaciones donde accedemos a un valor mediante una clave identificadora.
        Aspectos importantes:
        - Map no extiende la interfaz Collection. Aunque forma parte del Java Collections Framework, es una interfaz 
        independiente.
        - Map es una interfaz genérica que utiliza dos parámetros de tipo: Map<K, V>, donde K representa el tipo de las 
        claves y V el tipo de los valores.
        - Cada clave debe ser única dentro del mapa. Los valores, en cambio, pueden repetirse.
        - En un Map modificable, si utilizamos put() con una clave que ya existe, se reemplaza el valor asociado 
        anteriormente.
        - A partir de Java 8, Map incorpora el método default forEach(), que recibe un objeto de tipo BiConsumer.
        - BiConsumer es una interfaz funcional que recibe dos parámetros y no devuelve ningún resultado.
            Podemos implementarla mediante una expresión lambda que reciba la clave y el valor de cada elemento.
        - Map no dispone directamente de un método stream(). Sin embargo, es posible obtener streams a partir de las 
        colecciones que proporcionan sus métodos:
            keySet()   -> devuelve un Set con las claves.
            values()   -> devuelve una Collection con los valores.
            entrySet() -> devuelve un Set con los pares clave-valor.
        - El orden de recorrido depende de la implementación utilizada. Por ejemplo, HashMap no garantiza un orden de 
        iteración, mientras que LinkedHashMap mantiene un orden definido.
        */

        System.out.println("Interface Map");

        Map<String, String> mapaSemana;
        //K y V serían key(llave) y value(valor)
        //En este caso, tomamos a String como el tipo de dato para la llave y para el valor.
        //No se pueden declarar llaves ni valores del tipo de dato primitivo. 

        //Implementaciones de Map

        //HashMap
        //Implementa un mapa sin ningún tipo de orden garantizado. 
        //Es una de las implementaciones más eficientes para operaciones de inserción y búsqueda.
        // mapaSemana = new HashMap<>();

        //LinkedHashMap
        //Mantiene el orden de inserción. Lo que permite recorrer el mapa en el orden en que se agregaron los elementos.
        // mapaSemana = new LinkedHashMap<>();

        //TreeMap
        //Implementa NavigableMap y SortedMap. Ordena las claves según su orden natural, o mediante un Comparator.
        //Para ello, requiere que la clase de la clave implemente la interfaz Comparable.
        // mapaSemana = new TreeMap<>();

        //HashTable
        //Es una clase antigua que implementa la interfaz Map, es similar a HashMap, su ordenamiento es aleatorio.
        //No está deprecada, pero su uso no es recomendado en proyectos nuevos.
        //Sus métodos están sincronizados, lo que la hace safe thread, pero a costa de menor performance en 
        //comparación con HashMap.
        //Se mantiene para dar soporte a proyectos antiguos, aunque en desarrollo moderno, se prefiere utilizar
        //HashMap.
        mapaSemana = new  Hashtable<>();


        //con el método put() agrego un elemento
        mapaSemana.put("lu", "lunes");
        mapaSemana.put("ma", "martes");
        mapaSemana.put("mi", "miércoles");
        mapaSemana.put("ju", "jueves");
        mapaSemana.put("vi", "viernes");
        mapaSemana.put("sa", "sábado");
        mapaSemana.put("do", "domingo");
        //recordemos que no se pueden repetir las claves, pero sí los valores.

        //con get() obtenemos un elemento
        System.out.println(mapaSemana.get("vi"));

        System.out.println();

        mapaSemana.forEach((k,v) -> System.out.println(k + " " + mapaSemana.get(k)));

    }
}
