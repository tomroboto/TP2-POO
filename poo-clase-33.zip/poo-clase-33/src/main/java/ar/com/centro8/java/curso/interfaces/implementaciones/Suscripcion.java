package ar.com.centro8.java.curso.interfaces.implementaciones;

import ar.com.centro8.java.curso.interfaces.IPagos;

import lombok.Data;

@Data
public class Suscripcion implements IPagos {
    private final String plan;
    private final double mensual;


    @Override public void pagarConTarjetaDeDebito(double monto) {
        double total = aplicarDescuento(monto, 5);
        System.out.println("(Débito) Suscripción '" + plan + "' 5% OFF: " + redondearMonto(total));
    }

    @Override public void pagarConTarjetaDeCredito(double monto) {
        System.out.println("(Crédito) Suscripción '" + plan + "': " + redondearMonto(monto));
    }

    @Override public void pagarConTransferencia(double monto) {
        double total = aplicarDescuento(monto, 10);
        System.out.println("Transferencia Suscripción '" + plan + "' 10% OFF: " + redondearMonto(total));
    }

    @Override public void pagarConEfectivo(double monto) {
        System.out.println("Efectivo NO disponible para suscripciones");
    }

    @Override public void pagarConQR(double monto) {
        System.out.println("QR NO disponible para suscripciones");
    }

}
