package ar.com.centro8.java.curso.ejercicios.encapsulamiento.figuras.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Rectangulo {
    private double base;
    private double altura;

    public double informarPerimetro(){
        return (base + altura) * 2;
    }

    public double informarSuperficie(){
        return base * altura;
    }
}
