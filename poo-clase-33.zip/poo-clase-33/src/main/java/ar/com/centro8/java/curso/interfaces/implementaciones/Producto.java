package ar.com.centro8.java.curso.interfaces.implementaciones;

import ar.com.centro8.java.curso.interfaces.IPagos;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter 
@ToString 
@AllArgsConstructor 
public class Producto implements IPagos{
    private String nombre;
    private double precioBase;

    @Override
    public void pagarConTarjetaDeDebito(double monto) {
        // acá iría toda la lógica de pago con tarjeta de débito
        System.out.println("Se realizó el cobro con tarjeta de débito");
    }

    @Override
    public void pagarConTarjetaDeCredito(double monto) {
        // acá iría toda la lógica de pago con tarjeta de crédito
        System.out.println("Se aplicó un recargo del 10%");
        System.out.println("Total cobrado = " + redondearMonto(aplicarRecargo(monto, 10)));
    }

    @Override
    public void pagarConTransferencia(double monto) {
        // acá iría toda la lógica de pago con transferencia
        System.out.println("Se realizó el pago con transferencia");
    }

    @Override
    public void pagarConEfectivo(double monto) {
        // acá iría toda la lógica de pago con efectivo
        System.out.println("Se aplicó un descuento del 10%");
        System.out.println("Total cobrado = " + redondearMonto(aplicarDescuento(monto, 10)));
    }

    @Override
    public void pagarConQR(double monto) {
        // acá iría toda la lógica de pago con QR
        System.out.println("Se realizó el pago con QR");
    }


}
