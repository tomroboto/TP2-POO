package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.colecciones.Auto;

public class TestArrays {
    public static void main(String[] args) {
        System.out.println("Arrays - vectores");

        /*
         Un array es una estructura de datos en Java que permite almacenar múltiples valores 
         del mismo tipo de dato en una ubicación continua de memoria. 
         Se utiliza cuando necesitamos manejar un conjunto fijo de elementos relacionados.
         */

	    /*
            declaración:
            tipoDeDato[] identificador;  --> declaración
            tipoDeDato indentificador[]: --> declaración
            identificador = new tipoDeDato[n]; --> cantidad de elementos que va a tener
        */

        Auto[] autos;
        //solo se pueden almacenar elementos del tipo Auto.
        autos = new Auto[4];
        //la longitud del arreglo es de 4, esto quiere decir que va a almacenar 4 elementos, o sea, 4 autos.
        //Los arrays son estáticos. Esto significa que no lo puedo achicar ni agrandar.
        //Si necesito otro tamaño de arreglo, lo tengo que eliminar y volver a crear.
        //Otra forma de representar la declaración: Auto[] autos = new Auto[4];

        //los arreglos tienen un proceso de inicialización automático
        //los tipos de datos de datos referenciados se inician en null
        for (int i = 0; i < autos.length; i++) {
            System.out.println(autos[i]);
        }

        System.out.println();

        //asignación de valores
        autos[0] = new Auto("Fiat", "Palio", "Verde fosforescente");
        // autos[1] = "Hola"; ERROR, debe respetar el mismo tipo de dato
        autos[1] = new Auto("VW", "Gol", "Blanco eléctrico");
        autos[2] = new Auto("Renault", "Clio", "Rojo fuego");
        autos[3] = new Auto("Fiat", "Dos", "Gris amarillento");
        // autos[4] = new Auto("Ford", "Taunus", "Lila"); ERROR, no existe la posición de índice 4. 

        //mostrar todos los elementos de un arreglo
        System.out.println(autos); //no muestra el contenido
        //el nombre es una referencia. No es el contenido, muestra la ruta y su código hash

        //Para mostrar los elementos de un arreglo podemos utilizar la estructura for
        //esto genera un recorrido por índices
        for (int i = 0; i < autos.length; i++) {
            System.out.println(autos[i]);
        }
        System.out.println();

        //a partir del JDK 5 aparece la estructura for-each
        //la palabra clave o estructra for-each no está definida como palabra reservada del lenguaje, es el mismo
        //for que se comporta como un for-each
        for(Auto auto:autos) System.out.println(auto);
        //De la lista de autos, por cada elemento de la lista vamos a tener un objeto llamado auto, del tipo Auto.
        //El  for-each funciona tanto con arrays como con colecciones que implementan la interfaz Iterable
        //El for-each no sirve para agregar o eliminar elementos durante la iteración.
        //El for-each no tiene acceso al índice.

    }
}
