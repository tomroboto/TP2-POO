package ar.com.centro8.java.curso.ejercicios.herencia.figuras.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Circulo extends FiguraGeometrica{
    private double radio;

    @Override //la anotattion Override, no es obligatoria, pero se deja por buenas prácticas
    //y además hay herramientas externas que las leen.
    public double informarPerimetro(){
        return 2 * Math.PI * radio;
    }

    @Override 
    public double informarSuperficie(){
        return Math.PI * Math.pow(radio, 2);
    }

}
