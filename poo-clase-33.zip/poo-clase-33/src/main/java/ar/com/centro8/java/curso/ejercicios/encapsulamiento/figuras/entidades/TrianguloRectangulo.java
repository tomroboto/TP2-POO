package ar.com.centro8.java.curso.ejercicios.encapsulamiento.figuras.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class TrianguloRectangulo {
    private double base;
    private double altura;

    public double informarPerimetro(){
        return base + altura + Math.hypot(base, altura);
    }

    public double informarSuperficie(){
        return base * altura / 2;
    }

}
