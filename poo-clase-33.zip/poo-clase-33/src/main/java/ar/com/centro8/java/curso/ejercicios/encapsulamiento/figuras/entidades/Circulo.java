package ar.com.centro8.java.curso.ejercicios.encapsulamiento.figuras.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Circulo {
    private double radio;

    public double informarPerimetro(){
        return 2 * Math.PI * radio;
    }

    public double informarSuperficie(){
        return Math.PI * Math.pow(radio, 2);
    }

}
