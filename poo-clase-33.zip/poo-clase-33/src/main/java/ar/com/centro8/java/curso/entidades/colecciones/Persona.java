package ar.com.centro8.java.curso.entidades.colecciones;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor 
@Data 
public class Persona {
    private int id;
    private String nombre;
    private int edad;
}
